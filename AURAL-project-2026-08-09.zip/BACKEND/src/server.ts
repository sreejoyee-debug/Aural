import 'dotenv/config'
import cors from 'cors'
import express from 'express'
import jwt from 'jsonwebtoken'
import { z } from 'zod'

const app = express()
const port = Number(process.env.PORT ?? 4000)
const jwtSecret = process.env.JWT_SECRET ?? 'local-development-secret'

app.use(cors({ origin: process.env.CLIENT_ORIGIN ?? 'http://localhost:5173' }))
app.use(express.json())

type Recommendation = {
  title: string
  artist: string
  reason: string
  energy: number
}

/**
 * This narrow interface is the provider boundary.  Replace DemoMusicProvider
 * with Spotify/OpenAI/another provider without changing frontend contracts.
 */
interface MusicIntelligenceProvider {
  recommendFromMood(mood: string): Promise<Recommendation[]>
  replyAsDj(message: string): Promise<{ reply: string; queue: Recommendation[] }>
}

const demoTracks: Recommendation[] = [
  { title: 'Glass Horizon', artist: 'Luna Vale', reason: 'Dreamy guitars with a soft landing.', energy: 0.48 },
  { title: 'Blue Hour', artist: 'Aerial Days', reason: 'Gentle focus without the empty quiet.', energy: 0.35 },
  { title: 'Night Signals', artist: 'Sundial Club', reason: 'A warm pulse for the drive home.', energy: 0.62 },
]

class DemoMusicProvider implements MusicIntelligenceProvider {
  async recommendFromMood(mood: string) {
    return demoTracks.map((track, index) => ({ ...track, reason: `${track.reason} Tuned for ${mood}.`, energy: Number((track.energy + index * 0.03).toFixed(2)) }))
  }

  async replyAsDj(message: string) {
    const mention = message.toLowerCase().includes('exam')
      ? 'You earned a little exhale. I started gentle, then added a bright reset near the middle.'
      : 'I heard the mood beneath the words. I shifted your queue toward warmth, space, and a little forward motion.'
    return { reply: mention, queue: await this.recommendFromMood(message) }
  }
}

const music = new DemoMusicProvider()
const globe = {
  India: { genres: ['Bollywood', 'Punjabi', 'Carnatic'], artists: ['Anuv Jain', 'Prateek Kuhad', 'Shubh'], listeners: '42.8M' },
  Japan: { genres: ['City Pop', 'Anime', 'Jazz'], artists: ['Fujii Kaze', 'Lamp', 'Miki Matsubara'], listeners: '31.2M' },
  Brazil: { genres: ['Samba', 'Bossa Nova', 'Baile funk'], artists: ['Anitta', 'Seu Jorge', 'Liniker'], listeners: '26.4M' },
}

app.get('/health', (_request, response) => response.json({ status: 'ok', service: 'aural-api' }))

app.post('/api/auth/session', (request, response) => {
  const body = z.object({ email: z.string().email().optional(), name: z.string().min(1).max(60).optional() }).safeParse(request.body)
  if (!body.success) return response.status(400).json({ error: 'Provide a valid email or display name.' })
  const user = { id: 'demo-user', name: body.data.name ?? 'Sahas', email: body.data.email ?? 'listener@aural.local' }
  return response.json({ user, token: jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: '7d' }) })
})

app.get('/api/discovery/mood/:mood', async (request, response) => {
  const mood = decodeURIComponent(request.params.mood)
  return response.json({ mood, palette: mood.toLowerCase().includes('rain') ? '#6da8ff' : '#9b83ff', tracks: await music.recommendFromMood(mood) })
})

app.post('/api/discovery/dj', async (request, response) => {
  const body = z.object({ message: z.string().min(2).max(500) }).safeParse(request.body)
  if (!body.success) return response.status(400).json({ error: 'A DJ message between 2 and 500 characters is required.' })
  return response.json(await music.replyAsDj(body.data.message))
})

app.get('/api/globe/:country', (request, response) => {
  const country = decodeURIComponent(request.params.country)
  const signal = globe[country as keyof typeof globe]
  if (!signal) return response.status(404).json({ error: 'That region is not in the demo globe yet.' })
  return response.json({ country, ...signal })
})

app.get('/api/weather/mix', (request, response) => {
  const condition = String(request.query.condition ?? 'cloudy').toLowerCase()
  const mix = condition.includes('rain')
    ? { condition: 'rain', genres: ['Lo-fi', 'Acoustic', 'Coffeehouse'], animation: 'rain' }
    : condition.includes('sun')
      ? { condition: 'sunny', genres: ['Summer Pop', 'Dance', 'Roadtrip'], animation: 'sun-rays' }
      : { condition: 'cloudy', genres: ['Dream Pop', 'Ambient', 'Indie'], animation: 'clouds' }
  return response.json({ ...mix, tracks: demoTracks })
})

app.listen(port, () => console.log(`AURAL API listening at http://localhost:${port}`))
